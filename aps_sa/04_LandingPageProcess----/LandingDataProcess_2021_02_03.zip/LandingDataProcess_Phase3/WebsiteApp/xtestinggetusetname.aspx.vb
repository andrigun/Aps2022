﻿Imports System.Web
Imports System.Web.Security

Public Class xtestinggetusetname
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' Find if user is logged in
        If (Context.User.Identity.IsAuthenticated) Then
            ' Finds user name and says Hi
            lblwelcome.Text = "Hi " + Context.User.Identity.Name

        Else

            ' It is anonymous user, say hi to guest
            lblwelcome.Text = "Hi guest"
        End If

        Dim x As String
        Dim win As System.Security.Principal.WindowsIdentity
        win = System.Security.Principal.WindowsIdentity.GetCurrent()
        Dim _UserName = win.Name.Substring(win.Name.IndexOf("\") + 1)
        x = Environment.UserName

    End Sub

End Class