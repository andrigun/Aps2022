﻿Imports System.Data
Imports System.Data.SqlClient

Public Class clsQry
    Dim sqlconapps As New SqlConnection(ConfigurationManager.ConnectionStrings("Conapps").ConnectionString)

    Public Function getListCamSurvey(ByVal currPage As Integer, ByVal rowPerPage As Integer,
      ByRef totalPage As Integer, ByVal reffnumber As String) As DataSet

		Dim oDs6 As Object
        Dim oData As New ClsData
        Dim sCmd As String
        Dim iErrNo

        sCmd = "exec usp_qry_CAMsurvey_BNFMOSS '" & reffnumber & "'"
        'sCmd = "select top 10 * from BNF_CONFINSMin1..COLL_AGRMNT"

        'oDs6 = oData.ExecuteQuery(sCmd, clsData.ReturnType.Paging, currPage, rowPerPage, totalPage)
        oDs6 = oData.executeQuery(sCmd, ClsData.ReturnType.DataSet)

		Return oDs6

    End Function
    Public Function getListCalcuRefundDis(ByVal currPage As Integer, ByVal rowPerPage As Integer,
      ByRef totalPage As Integer, ByVal reffnumber As String) As DataSet

		Dim oDs6 As Object
        Dim oData As New ClsData
        Dim sCmd As String
        Dim iErrNo

        sCmd = "exec uspRefundDisBurse '" & reffnumber & "'"
        'sCmd = "select top 10 * from BNF_CONFINSMin1..COLL_AGRMNT"

        'oDs6 = oData.ExecuteQuery(sCmd, clsData.ReturnType.Paging, currPage, rowPerPage, totalPage)
        oDs6 = oData.executeQuery(sCmd, ClsData.ReturnType.DataSet)

		Return oDs6

	End Function
    Public Function loadCalculatorRefund(ByVal dfcId As Integer) As DataSet
        Dim oDs As DataSet
        Dim oData As New ClsData
        Dim sCmd As String

        sCmd = "exec uspRefundMax '" & dfcId & "'"

        oDs = oData.ExecuteQuerydisplaydatapagedetailreview(sCmd, ClsData.ReturnType.Paging, 1, 10, 0)
        Return oDs
    End Function
	Public Function loadCalculatorCredit_tes(ByVal dfcid As Integer) As DataSet
		' MsgBox("masuk query")
		Dim oDs As Object
		Dim oData As New ClsData
		Dim sCmd As String
		Dim iErrNo

		sCmd = "exec displaydatacalculator '" & dfcid & "'"
		oDs = oData.executeQuery(sCmd, ClsData.ReturnType.DataSet, iErrNo)
		Return oDs

	End Function

    Public Function loadCalculatorCredit(ByVal dfcId As Integer) As DataSet
        Dim oDs As DataSet
        Dim oData As New ClsData
        Dim sCmd As String

        sCmd = "exec displaydatacalculator '" & dfcId & "'"

        oDs = oData.ExecuteQuerydisplaydatapagedetailreview(sCmd, ClsData.ReturnType.Paging, 1, 10, 0)
        Return oDs
    End Function

    Public Function loadCalculatorCreditHistory(ByVal dfcId As Integer) As DataSet
        Dim oDs As DataSet
        Dim oData As New ClsData
        Dim sCmd As String

        sCmd = "exec displaydatacalculatorHistory '" & dfcId & "'"

        oDs = oData.ExecuteQuerydisplaydatapagedetailreview(sCmd, ClsData.ReturnType.Paging, 1, 10, 0)
        Return oDs
    End Function
End Class
