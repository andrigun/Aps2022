Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Mail
Imports Microsoft.VisualBasic

Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.HtmlControls
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.WebControls.ListControl
Imports System.Web.UI.WebControls.ListBox


Public Class ClsSendMail_SubmitCabang
    Public SmtpServer As String = ConfigurationSettings.AppSettings("SmtpServer")
    Dim sqlconapps As New SqlConnection(ConfigurationManager.ConnectionStrings("Conapps").ConnectionString)

	Public sender_sam As String = ConfigurationSettings.AppSettings("sender_sam")

    Public cp_sam1 As String = ConfigurationSettings.AppSettings("cp_sam1")
    Public cp_sam2 As String = ConfigurationSettings.AppSettings("cp_sam2")
    Public cp_sam3 As String = ConfigurationSettings.AppSettings("cp_sam3")
    Public cp_sam4 As String = ConfigurationSettings.AppSettings("cp_sam4")
    Public cp_sam5 As String = ConfigurationSettings.AppSettings("cp_sam5")


	Public sam_to As String = ConfigurationSettings.AppSettings("sam_to")
    Public sam_cc As String = ConfigurationSettings.AppSettings("sam_cc")
    Public sam_bcc As String = ConfigurationSettings.AppSettings("sam_bcc")
    Dim var_applicationid As String
    Dim var_assetseqno As Integer

    Dim oLoad As New ClsApp
    Dim fotocount As Integer

    Public Function SendMail(ByVal szSendTo As String, ByVal szSendFrom As String, ByVal szFromName As String, _
               ByVal notiftype As Integer, ByVal applicationid As String, ByVal assetseqno As String) As Boolean

        Dim oLoad As New ClsApp
        Dim oDs As New DataSet

        Dim sQuery As String

		'Dim jmlfoto As Integer
		'Dim emailcabang As String

		'    oDs = oLoad.DisplayAgrementAssetNo(Left(applicationid, 3), applicationid, assetseqno)

		var_applicationid = applicationid
		var_assetseqno = 5

		Dim isibody As String
        Dim konfis As String

		'      sQuery = "select distinct alamatpool, isnull(kondisi,'') kondisi, fotoid, fotodesc, isnull(fotofile,'') fotofile, MAR_ProsesPenjualan_Internal.statusproses, CONVERT(VARCHAR(11),  " & _
		'          "MAR_ProsesPenjualanextlelang_Internal.tglmulailelang, 106) AS tglmulailelang, CONVERT(VARCHAR(11), MAR_ProsesPenjualanextlelang_Internal.tglakhirlelang, 106) AS tglakhirlelang, mar_asset.assetdescription_correctionsam,  " & _
		'          "isnull(REPLACE(CONVERT(VARCHAR,CONVERT(MONEY, MAR_ProsesPenjualanExtLelang_Internal.offeringprice),1), '.000',''),0) as offeringprice, isnull(MAR_ProsesPenjualanExtLelang_Internal.offeringprice,0) as offeringpricenumber,  " & _
		'          "MAR_msStatusProses.statusprosesdesc, CONVERT(VARCHAR(11), mar_kondisifisik_internal.masastnk, 106) AS masastnk, CONVERT(VARCHAR(11), mar_kondisifisik_internal.masapajak, 106) AS masapajak," & _
		'          "a.prod_type as producttype, " & _
		'          "'' as  iscfpsgu,  " & _
		'          "a.agrmnt_no as agreementno, " & _
		'          "ltrim(refof.office_name) as branchfullname, " & _
		'          "cust.cust_name as name " & _
		'          "from mar_alamatpool_internal  with(nolock)   " & _
		'          "left join mar_kondisifisik_internal with(nolock)  on mar_alamatpool_internal.applicationid = mar_kondisifisik_internal.applicationid  and mar_alamatpool_internal.assetseqno = mar_kondisifisik_internal.assetseqno   " & _
		'          "left join mar_foto_internal with(nolock)  on mar_alamatpool_internal.applicationid = mar_foto_internal.applicationid  and mar_alamatpool_internal.assetseqno=mar_foto_internal.assetseqno   " & _
		'          "left join MAR_ProsesPenjualan_Internal with(nolock)  on mar_alamatpool_internal.applicationid = MAR_ProsesPenjualan_Internal.applicationid and mar_alamatpool_internal.assetseqno = MAR_ProsesPenjualan_Internal.assetseqno   " & _
		'          "left join MAR_ProsesPenjualanextlelang_Internal with(nolock)  on MAR_ProsesPenjualan_Internal.applicationid = MAR_ProsesPenjualanextlelang_Internal.applicationid and MAR_ProsesPenjualan_Internal.assetseqno = MAR_ProsesPenjualanextlelang_Internal.assetseqno   " & _
		'          "left join MAR_Asset with(nolock)  on MAR_ProsesPenjualan_Internal.applicationid = MAR_Asset.applicationid and MAR_ProsesPenjualan_Internal.assetseqno = MAR_asset.assetseqno   " & _
		'          "left join MAR_msStatusProses with(nolock)  on MAR_ProsesPenjualan_Internal.statusproses = MAR_msStatusProses.statusproses   "

		'      sQuery = sQuery & "left join bnf_confinsmin1.dbo.app with (nolock) on mar_alamatpool_internal.applicationid = app.app_no " & _
		'          "left join bnf_confinsmin1.dbo.agrmnt a with (nolock) on app.app_id = a.app_id " & _
		'          "left join bnf_confinsmin1.dbo.ref_office REFOF with (nolock) on a.ref_office_id = REFOF.ref_office_id  " & _
		'          "left join bnf_confinsmin1.dbo.cust  with(nolock) ON a.Cust_ID = Cust.Cust_ID   "
		'sQuery = sQuery & "where mar_alamatpool_internal.branchid='" & Left(applicationid, 3) & "' and mar_alamatpool_internal.applicationid='" & applicationid & "' and mar_alamatpool_internal.assetseqno='" & assetseqno & "'"

		'Dim oAdapter As New SqlDataAdapter(sQuery, sqlconapps)
		'      Dim oDsmar As New DataSet
		'      oAdapter.Fill(oDsmar, "DataSet")

		'      notiftype = oDsmar.Tables(0).Rows(0).Item(5)

		notiftype = 7


		If notiftype = 7 Then
            isibody = "<center><u><b><font style='font-family: Tahoma;font-size:large;'>" & ConfigurationSettings.AppSettings("annlelang") & "</font></b></u></center><br>"
        Else
            isibody = "<center><u><b><font style='font-family: Tahoma;font-size:large;'>" & ConfigurationSettings.AppSettings("annlangsung") & "</font></b></u></center><br>"
        End If

        isibody = isibody & "<table id='tbGrid1' cellSpacing='1' cellPadding='2'  border='0' width='853px' align='center'>"
        isibody = isibody & "<tr><td align='left' style='font-family: Tahoma;font-size:smaller;BORDER-RIGHT: 0px; BORDER-TOP: 0px; BORDER-LEFT: 0px; BORDER-BOTTOM: 0px; BACKGROUND-COLOR: #e7e3e7;' colspan=3><b>INFORMASI ASSET</b></td></tr>"

        isibody = isibody & "<tr>"
        isibody = isibody & "<td style='width:22%;BACKGROUND-COLOR:#f4faff;font-family: Tahoma;font-size:smaller;'>Cabang</td><td>:</td>"
		isibody = isibody & "<td style='width:78%;BACKGROUND-COLOR:#ffffff;font-family: Tahoma;font-size:smaller;'>TESTING</td>"
		isibody = isibody & "</tr>"

		'isibody = isibody & "<tr>"
		'isibody = isibody & "<td style='width:22%;BACKGROUND-COLOR:#f4faff;font-family: Tahoma;font-size:smaller;'>Nama Customer / Agreement No.</td><td>:</td>"
		'isibody = isibody & "<td style='width:78%;BACKGROUND-COLOR:#ffffff;font-family: Tahoma;font-size:smaller;'>" & oDsmar.Tables(0).Rows(0).Item(18) & " / " & oDsmar.Tables(0).Rows(0).Item(16) & "</td>"
		'isibody = isibody & "</tr>"

		'isibody = isibody & "<tr>"
		'      isibody = isibody & "<td style='width:22%;BACKGROUND-COLOR:#f4faff;font-family: Tahoma;font-size:smaller;'>Nama / Jenis Asset</td><td>:</td>"
		'      isibody = isibody & "<td style='width:78%;BACKGROUND-COLOR:#ffffff;font-family: Tahoma;font-size:smaller;'>" & oDsmar.Tables(0).Rows(0).Item(8) & "</td>"
		'      isibody = isibody & "</tr>"

		'      isibody = isibody & "<tr>"
		'      isibody = isibody & "<td style='width:22%;BACKGROUND-COLOR:#f4faff;font-family: Tahoma;font-size:smaller;'>No. Rangka</td><td>:</td>"
		'      isibody = isibody & "<td style='width:78%;BACKGROUND-COLOR:#ffffff;font-family: Tahoma;font-size:smaller;'>" & oDs.Tables(0).Rows(0).Item(6) & "</td>"
		'      isibody = isibody & "</tr>"

		'      isibody = isibody & "<tr>"
		'      isibody = isibody & "<td style='width:22%;BACKGROUND-COLOR:#f4faff;font-family: Tahoma;font-size:smaller;'>No. Mesin</td><td>:</td>"
		'      isibody = isibody & "<td style='width:78%;BACKGROUND-COLOR:#ffffff;font-family: Tahoma;font-size:smaller;'>" & oDs.Tables(0).Rows(0).Item(7) & "</td>"
		'      isibody = isibody & "</tr>"

		'      isibody = isibody & "<tr>"
		'      isibody = isibody & "<td style='width:22%;BACKGROUND-COLOR:#f4faff;font-family: Tahoma;font-size:smaller;'>Manufacturing Year</td><td>:</td>"
		'      isibody = isibody & "<td style='width:78%;BACKGROUND-COLOR:#ffffff;font-family: Tahoma;font-size:smaller;'>" & oDs.Tables(0).Rows(0).Item(10) & "</td>"
		'      isibody = isibody & "</tr>"
		'      isibody = isibody & "<tr>"
		'      isibody = isibody & "<td style='width:22%;BACKGROUND-COLOR:#f4faff;font-family: Tahoma;font-size:smaller;'>Color</td><td>:</td>"
		'      isibody = isibody & "<td style='width:78%;BACKGROUND-COLOR:#ffffff;font-family: Tahoma;font-size:smaller;'>" & oDs.Tables(0).Rows(0).Item(9) & "</td>"
		'      isibody = isibody & "</tr>"
		'      isibody = isibody & "<tr>"
		'      isibody = isibody & "<td style='width:22%;BACKGROUND-COLOR:#f4faff;font-family: Tahoma;font-size:smaller;'>License Plate (Kode Wilayah)</td><td>:</td>"

		'Dim str As String
		'      str = oDs.Tables(0).Rows(0).Item(8)
		'      str = str.Replace(" ", "")
		'      If Mid(str, 2, 1) = "0" Or Mid(str, 2, 1) = "1" Or Mid(str, 2, 1) = "2" Or Mid(str, 2, 1) = "3" Or Mid(str, 2, 1) = "4" Or Mid(str, 2, 1) = "5" Or Mid(str, 2, 1) = "6" Or Mid(str, 2, 1) = "7" Or Mid(str, 2, 1) = "8" Or Mid(str, 2, 1) = "9" Then
		'          str = Left(str, 1)
		'      Else
		'          str = Left(str, 2)
		'      End If

		'isibody = isibody & "<td style='width:78%;BACKGROUND-COLOR:#ffffff;font-family: Tahoma;font-size:smaller;'>" & oDs.Tables(0).Rows(0).Item(8) & "</td>"
		'      isibody = isibody & "</tr>"
		'      isibody = isibody & "<tr>"
		'      isibody = isibody & "<tr>"
		'      isibody = isibody & "<td style='width:22%;BACKGROUND-COLOR:#f4faff;font-family: Tahoma;font-size:smaller;'>Alamat Pool</td><td>:</td>"
		'      isibody = isibody & "<td style='width:78%;BACKGROUND-COLOR:#ffffff;font-family: Tahoma;font-size:smaller;'>" & oDsmar.Tables(0).Rows(0).Item(0) & "</td>"
		'      isibody = isibody & "</tr>"

		'isibody = isibody & "<tr>"
		'isibody = isibody & "<td style='width:22%;BACKGROUND-COLOR:#f4faff;font-family: Tahoma;font-size:smaller;'>Status</td><td>:</td>"

		'If Trim(oDsmar.Tables(0).Rows(0).Item(5)) = "7" Then
		'    isibody = isibody & "<td style='width:22%;BACKGROUND-COLOR:#ffffff;font-family: Tahoma;font-size:smaller;'>" & Trim(oDsmar.Tables(0).Rows(0).Item(11)) & " (" & oDsmar.Tables(0).Rows(0).Item(6) & " s/d " & oDsmar.Tables(0).Rows(0).Item(7) & ")</td>"
		'Else
		'    If ((Trim(oDsmar.Tables(0).Rows(0).Item(5)) = "6") Or (Trim(oDsmar.Tables(0).Rows(0).Item(5)) = "9") Or (Trim(oDsmar.Tables(0).Rows(0).Item(5)) = "10") Or (Trim(oDsmar.Tables(0).Rows(0).Item(5)) = "11")) Then
		'        isibody = isibody & "<td style='width:22%;BACKGROUND-COLOR:#ffffff;font-family: Tahoma;font-size:smaller;'>" & Trim(oDsmar.Tables(0).Rows(0).Item(11)) & "</td>"
		'    End If
		'End If
		'konfis = oDsmar.Tables(0).Rows(0).Item(1)

		'isibody = isibody & "</tr>"


		isibody = isibody & "</table><br>"


		'Dim x As String
		'x = ConfigurationSettings.AppSettings("ServerName")


		'Holds message information.
		Dim mailMessage As System.Net.Mail.MailMessage = New System.Net.Mail.MailMessage()

        'Tidak perlu diubah-ubah (sama untuk live maupun testing)
        Dim SendFrom As String = sender_sam

        '!!!!!!! ATTENTION !!!!!!!!!!!
        '##### UNTUK APLIKASI REAL #########
        Dim SendTo As String = sam_to
        Dim SendCC As String = sam_cc
        Dim SendBCC As String = sam_bcc
        '##### UNTUK APLIKASI REAL #########

        mailMessage.From = New System.Net.Mail.MailAddress(SendFrom)
        mailMessage.To.Add(SendTo)
        mailMessage.CC.Add(SendCC)
        mailMessage.Bcc.Add(SendBCC)

        If notiftype = 7 Then
            mailMessage.Subject = ConfigurationSettings.AppSettings("annlelang")
        Else
            mailMessage.Subject = ConfigurationSettings.AppSettings("annlangsung")
        End If

        'Create two views, one text, one HTML.
        Dim plainTextView As System.Net.Mail.AlternateView = System.Net.Mail.AlternateView.CreateAlternateViewFromString("body", Nothing, "text/plain")
        Dim htmlView As System.Net.Mail.AlternateView

        'cekfoto()

        'If fotocount = 0 Then
        htmlView = System.Net.Mail.AlternateView.CreateAlternateViewFromString("<html><body>" & isibody & "<br></body></html>", Nothing, "text/html")
        ' Else

        'htmlView = System.Net.Mail.AlternateView.CreateAlternateViewFromString("<html><body>" & isibody & "<br><center><b><font style='font-family: Tahoma;font-size:smaller;'>Gambar Asset</font></b><br><table border=2><tr><td><img src='cid:HDIImage1'></td></tr></table></center><br><br></body></html>", Nothing, "text/html")

        'Dim pic1 As String

        'pic1 = "c:\inetpub\wwwroot\pengelolaanut\imageunit\" & oDsmar.Tables(0).Rows(0).Item(4)
        'Dim imageResource1 As New System.Net.Mail.LinkedResource(pic1)
        'imageResource1.ContentId = "HDIImage1"
        'htmlView.LinkedResources.Add(imageResource1)

        'End If

        'Add two views to message.
        mailMessage.AlternateViews.Add(plainTextView)
        mailMessage.AlternateViews.Add(htmlView)

        'Send message
        Dim smtpClient As New System.Net.Mail.SmtpClient()
        smtpClient.Send(mailMessage)

        If sqlconapps.State = ConnectionState.Open Then
            sqlconapps.Close()
        End If

    End Function


    Sub cekfoto()
        If sqlconapps.State = ConnectionState.Closed Then
            sqlconapps.Open()
        End If
        Dim sQueryx As String
        sQueryx = "select distinct fotoid, fotodesc, isnull(fotofile,'') fotofile " & _
        "from mar_alamatpool_internal " & _
        "inner join mar_foto_internal on mar_alamatpool_internal.applicationid = mar_foto_internal.applicationid  and mar_alamatpool_internal.assetseqno=mar_foto_internal.assetseqno " & _
        "where mar_alamatpool_internal.branchid='" & Left(var_applicationid, 3) & "' and mar_alamatpool_internal.applicationid='" & var_applicationid & "' and mar_alamatpool_internal.assetseqno='" & var_assetseqno & "'" ' and fotoid<>null"

        Dim oAdapter As New SqlDataAdapter(sQueryx, sqlconapps)
        Dim oDsmar As New DataSet
        oAdapter.Fill(oDsmar, "DataSet")

        fotocount = oDsmar.Tables(0).Rows.Count

        If sqlconapps.State = ConnectionState.Open Then
            sqlconapps.Close()
        End If

    End Sub

    Public Function Terbilang(ByVal nilai As Long) As String
        Dim bilangan As String() = {"", "satu", "dua", "tiga", "empat", "lima", _
        "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas"}
        If nilai < 12 Then
            Return " " & bilangan(nilai)
        ElseIf nilai < 20 Then
            Return Terbilang(nilai - 10) & " belas"
        ElseIf nilai < 100 Then
            Return (Terbilang(CInt((nilai \ 10))) & " puluh") + Terbilang(nilai Mod 10)
        ElseIf nilai < 200 Then
            Return " seratus" & Terbilang(nilai - 100)
        ElseIf nilai < 1000 Then
            Return (Terbilang(CInt((nilai \ 100))) & " ratus") + Terbilang(nilai Mod 100)
        ElseIf nilai < 2000 Then
            Return " seribu" & Terbilang(nilai - 1000)
        ElseIf nilai < 1000000 Then
            Return (Terbilang(CInt((nilai \ 1000))) & " ribu") + Terbilang(nilai Mod 1000)
        ElseIf nilai < 1000000000 Then
            Return (Terbilang(CInt((nilai \ 1000000))) & " juta") + Terbilang(nilai Mod 1000000)
        ElseIf nilai < 1000000000000 Then
            Return (Terbilang(CInt((nilai \ 1000000000))) & " milyar") + Terbilang(nilai Mod 1000000000)
        ElseIf nilai < 1000000000000000 Then
            Return (Terbilang(CInt((nilai \ 1000000000000))) & " trilyun") + Terbilang(nilai Mod 1000000000000)
        Else
            Return ""
        End If
    End Function

End Class
