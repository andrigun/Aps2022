﻿    function open_url(par_URL){
        window.location.href = par_URL;
    }    