﻿Public Class rolesimulation
	Inherits System.Web.UI.Page

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

	End Sub

	Protected Sub btnBPCD_Click(sender As Object, e As EventArgs) Handles btnBPCD.Click
		Session("userid") = "UserBPCD"
		Session("branchid") = "801"
		Session("branchname") = "Kemayoran"
		Session("akses") = "BPCD"
		Response.Redirect("./form/BPCD_StartPage.aspx")
	End Sub


	Protected Sub btnADMIN_Click(sender As Object, e As EventArgs) Handles btnADMIN.Click
		Session("userid") = "UserADMIN"
		Session("branchid") = "801"
		Session("branchname") = "Kemayoran"
		Session("akses") = "ADMIN"
		Response.Redirect("./form/Admin_StartPage.aspx")
	End Sub

	Protected Sub btnCA_Click(sender As Object, e As EventArgs) Handles btnCA.Click
		Session("userid") = "UserCA"
		Session("branchid") = "801"
		Session("branchname") = "Kemayoran"
		Session("akses") = "CA"
		Response.Redirect("./form/CA_StartPage.aspx")
	End Sub

	'Protected Sub btnCC_Click(sender As Object, e As EventArgs) Handles btnCC.Click
	'	Session("userid") = "UserCC"
	'	Session("branchid") = "801"
	'	Session("branchname") = "Kemayoran"
	'	Session("akses") = "CustomerCare"
	'	Response.Redirect("./form/CC_StartPage.aspx")
	'End Sub

	Protected Sub btnBM_Click(sender As Object, e As EventArgs) Handles btnBM.Click
		Session("userid") = "UserBM"
		Session("branchid") = "801"
		Session("branchname") = "Kemayoran"
		Session("akses") = "BM"
		Response.Redirect("./form/BM_StartPage.aspx")
	End Sub

	'Protected Sub btnPublic_Click(sender As Object, e As EventArgs) Handles btnPublic.Click
	'	Session("userid") = "UserPubic"
	'	Session("branchid") = "801"
	'	Session("branchname") = "Kemayoran"
	'	Session("akses") = "Public"
	'	Response.Redirect("./form/Public_StartPage.aspx")
	'End Sub
End Class