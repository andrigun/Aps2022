﻿Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient
Imports System
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.IO
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.ComponentModel

Public Class ServiceHeader : Inherits SoapHeader
    Public usernameWS As String
    Public PasswordWS As String
End Class

Public Class ClsApp
    Inherits System.Web.Services.WebService
    Public secheader As ServiceHeader
    Dim sErrDesc As String
    Dim ErrDesc As String
    Dim sqlconapps As New SqlConnection(ConfigurationManager.ConnectionStrings("Conapps").ConnectionString)

    <WebMethod(enableSession:=True)> _
    Public Function display_DataUs(ByVal pUs As String, ByVal pPw As String, ByVal pStr As String) As DataSet
        Dim oDs As DataSet
        Dim oData As New ClsData
        Dim sCmd As String = ""
        GlobalVariables.GlobaUserName_var = "abc"
        GlobalVariables.GlobalUserPass_var = pPw

        Dim r As New System.Text.RegularExpressions.Regex("^[a-zA-Z _.0-9]+$")
        If (r.IsMatch(pUs) = True And r.IsMatch(pPw) = True) Then
            sCmd = "exec display_LoginAccess_UserWeb '" & pUs & "', '" & pPw & "','" & pStr & "'"
        End If
        oDs = oData.executeQuerydisplay_DataUser(sCmd, ClsData.ReturnType.DataSet)
        With oDs.Tables(0)
            GlobalVariables.GlobaUserName = .Rows(0).Item("UserName")
            GlobalVariables.GlobalBranchId = .Rows(0).Item("BranchFullName")
            GlobalVariables.GlobalBranchFullName = .Rows(0).Item("BranchID")
            GlobalVariables.GlobalUserPass = .Rows(0).Item("pass")
        End With
        Return oDs
    End Function

	'dipakai page
	Public Function displaydataPageStatus(ByVal Akses As String, ByVal BranchId As String, ByVal Str2 As String, ByVal Str3 As String, ByVal currPage As Integer, ByVal rowPerPage As Integer, ByRef totPage As Integer, ByVal orderBy As String, ByVal AscDesc As String) As DataSet
		Dim oDs As DataSet
		Dim oData As New ClsData
		Dim sCmd As String
		sCmd = "exec displaydatapagestatus '" & Akses & "','" & BranchId & "', '" & Str2 & "','" & Str3 & "'"
		oDs = oData.ExecuteQueryPageStatus(sCmd, ClsData.ReturnType.Paging, currPage, 10000, 1)

		Return oDs
	End Function

	'dipakai
	Public Function displayDataPageStatusList(ByVal Akses As String, ByVal statusid As String, ByVal searchname As String, ByVal BranchID As String, ByVal currPage As Integer, ByVal rowPerPage As Integer, ByRef totPage As Integer, ByRef totRow As Integer, ByVal orderBy As String, ByVal AscDesc As String, ByVal filtering1 As String, ByVal filtering2 As String, ByVal filtering3 As String) As DataSet
		Dim oDs As DataSet
		Dim oData As New ClsData
		Dim sCmd As String

		If ((statusid = "allstatus") Or (statusid = "")) Then
			statusid = "%"
			If searchname = "" Then searchname = "%"
		End If

		'sCmd = "exec displayDataPageStatusList '" & Akses & "','" & statusid & "', '" & searchname & "', '" & BranchID & "'"

		'tambahan feature sort sortings

		sCmd = "exec displayDataPageStatusList_sortsupport '" & Akses & "','" & statusid & "', '" & searchname & "', '" & BranchID & "', '" & orderBy & "', '" & AscDesc & "', '" & filtering1 & "', '" & filtering2 & "', '" & filtering3 & "'"

		oDs = oData.ExecuteQueryPaging(sCmd, ClsData.ReturnType.Paging, currPage, rowPerPage, totPage, totRow)

		Return oDs
	End Function
	'Public Function displayCamSurvey(ByVal orderNo As String, ByVal currPage As Integer, ByVal rowPerPage As Integer, ByRef totPage As Integer, ByRef totRow As Integer, ByVal orderBy As String, ByVal AscDesc As String) As DataSet
	'    Dim oDs As DataSet
	'    Dim oData As New ClsData
	'    Dim sCmd As String


	'    sCmd = "exec usp_qry_CAMsurvey_BNFMOSS '" & orderNo & "'"
	'    oDs = oData.ExecuteQueryPaging(sCmd, ClsData.ReturnType.Paging, currPage, rowPerPage, totPage, totRow)

	'    Return oDs
	'End Function

	'dipakai page
	Public Function displaydatapagedetailreview(ByVal str As String) As DataSet
        Dim oDs As DataSet
        Dim oData As New ClsData
        Dim sCmd As String

        sCmd = "exec displaydatapagedetailreview '" & str & "'"

        oDs = oData.ExecuteQuerydisplaydatapagedetailreview(sCmd, ClsData.ReturnType.Paging, 1, 10, 0)
        Return oDs
    End Function
	'dipakai page
	'Public Function displaydatasurveyurutan(ByVal str As String) As DataSet
	'    Dim oDs As DataSet
	'    Dim oData As New ClsData
	'    Dim sCmd As String

	'    sCmd = "exec displaydatasurveyurutan '" & str & "'"

	'    oDs = oData.ExecuteQuerydisplaydatapagedetailreview(sCmd, ClsData.ReturnType.Paging, 1, 10, 0)
	'    Return oDs
	'End Function

	'Public Function displaydatapagesurvey(ByVal str As String) As DataSet
	'       Dim oDs As DataSet
	'       Dim oData As New ClsData
	'       Dim sCmd As String

	'       sCmd = "exec displaydatapagesurvey '" & str & "'"

	'       oDs = oData.ExecuteQuerydisplaydatapagedetailreview(sCmd, ClsData.ReturnType.Paging, 1, 10, 0)
	'       Return oDs
	'   End Function

	'calculator
	'Public Function displaydatacalculator(ByVal str As String) As DataSet
	'       Dim oDs As DataSet
	'       Dim oData As New ClsData
	'       Dim sCmd As String

	'       sCmd = "exec displaydatacalculator '" & str & "'"

	'       oDs = oData.ExecuteQuerydisplaydatapagedetailreview(sCmd, ClsData.ReturnType.Paging, 1, 10, 0)
	'       Return oDs
	'   End Function
	'load data survey I
	'Public Function displaydatasurveyInII(ByVal str As String, ByVal str2 As String) As DataSet
	'       Dim oDs As DataSet
	'       Dim oData As New ClsData
	'       Dim sCmd As String

	'       sCmd = "exec usp_qry_survey_BNFMOSS '" & str & "','" & str2 & "'"

	'       oDs = oData.ExecuteQuerydisplaydatapagedetailreview(sCmd, ClsData.ReturnType.Paging, 1, 10, 0)
	'       Return oDs
	'   End Function
	'Public Function displaydatasurveyurutan(ByVal dfcId As Integer, ByVal noOrderConfins As String) As DataSet
	'       Dim oDs As DataSet
	'       Dim oData As New ClsData
	'       Dim sCmd As String

	'       sCmd = "exec getdatasurveyurutan '" & dfcId & "','" & noOrderConfins & "'"

	'       oDs = oData.ExecuteQuerydisplaydatapagedetailreview(sCmd, ClsData.ReturnType.Paging, 1, 10, 0)
	'       Return oDs
	'   End Function

	'dipakai dropdownlist
	Public Function displaydropdownlistcancel(ByVal str As String) As DataSet
		Dim oDs As DataSet
		Dim oData As New ClsData
		Dim sCmd As String

		sCmd = "exec displaycancelcause '" & str & "'"

		oDs = oData.ExecuteQuerydisplaydatapagedetailreview(sCmd, ClsData.ReturnType.Paging, 1, 10, 0)
		Return oDs
	End Function

	'dipakai untuk mendapatkan nama status berdasarkan statusid
	Public Function displaystatusname(ByVal str As String) As DataSet
		Dim oDs As DataSet
		Dim oData As New ClsData
		Dim sCmd As String

		sCmd = "exec displaystatusname '" & str & "'"

		oDs = oData.ExecuteQuerydisplaydatapagedetailreview(sCmd, ClsData.ReturnType.Paging, 1, 10, 0)
		Return oDs
	End Function

	''tidak dipakai
	'Public Function save_Data_Approval(ByVal approval As String, ByVal note As String, ByVal user As String, ByVal cabang As String, ByVal dataid As String) As String
	'	Dim oData As New ClsData
	'	If Not oData.openConnection Then
	'		Return False
	'		sErrDesc = "Database Connection Failed."
	'	End If
	'	oData.beginTrans()
	'	Try
	'		Dim sCmd As String
	'		sCmd = "exec saveDataApproval '" & note & "','" & note & "'," &
	'												"'" & note & "','" & Replace(note, ",", "") & "','" & note & "'"
	'		oData.oCommand.CommandType = CommandType.Text
	'		oData.oCommand.CommandText = sCmd
	'		oData.oCommand.ExecuteNonQuery()
	'		oData.commitTrans()
	'		oData.closeConnection()
	'		Return True
	'	Catch ex As Exception
	'		sErrDesc = "Source : " & ex.Source & " , Desc : " & ex.Message
	'		oData.rollbackTrans()
	'		oData.closeConnection()
	'		Return False
	'	End Try
	'End Function


	'dipakai
	Public Function save_setdatastatus(ByVal setstatus As String, ByVal note As String, ByVal user As String, ByVal cabang As String, ByVal dataid As String, ByVal cancelid As String) As String
		Dim oData As New ClsData
		If Not oData.openConnection Then
			Return False
			sErrDesc = "Database Connection Failed."
		End If
		oData.beginTrans()
		Try
			Dim sCmd As String
			sCmd = "exec savesetstatus '" & setstatus & "','" & note & "'," &
													"'" & user & "','" & cabang & "','" & dataid & "','" & cancelid & "'"
			oData.oCommand.CommandType = CommandType.Text
			oData.oCommand.CommandText = sCmd
			oData.oCommand.ExecuteNonQuery()
			oData.commitTrans()
			oData.closeConnection()
			Return True
		Catch ex As Exception
			sErrDesc = "Source : " & ex.Source & " , Desc : " & ex.Message
			oData.rollbackTrans()
			oData.closeConnection()
			Return False
		End Try
	End Function

	Public Function notif_to_BM_dropdata(ByVal setstatus As String, ByVal note As String, ByVal user As String, ByVal cabang As String, ByVal dataid As String, ByVal cancelid As String) As String
		Dim oData As New ClsData
		If Not oData.openConnection Then
			Return False
			sErrDesc = "Database Connection Failed."
		End If
		oData.beginTrans()
		Try
			Dim sCmd As String
			sCmd = "exec notif_to_BM_dropdata '" & setstatus & "','" & note & "'," &
													"'" & user & "','" & cabang & "','" & dataid & "','" & cancelid & "'"
			oData.oCommand.CommandType = CommandType.Text
			oData.oCommand.CommandText = sCmd
			oData.oCommand.ExecuteNonQuery()
			oData.commitTrans()
			oData.closeConnection()
			Return True
		Catch ex As Exception
			sErrDesc = "Source : " & ex.Source & " , Desc : " & ex.Message
			oData.rollbackTrans()
			oData.closeConnection()
			Return False
		End Try
	End Function

	Public Function notif_to_CRA_rerequest(ByVal setstatus As String, ByVal note As String, ByVal user As String, ByVal cabang As String, ByVal dataid As String, ByVal cancelid As String) As String
		Dim oData As New ClsData
		If Not oData.openConnection Then
			Return False
			sErrDesc = "Database Connection Failed."
		End If
		oData.beginTrans()
		Try
			Dim sCmd As String
			sCmd = "exec notif_to_CRA_rerequest '" & setstatus & "','" & note & "'," &
													"'" & user & "','" & cabang & "','" & dataid & "','" & cancelid & "'"
			oData.oCommand.CommandType = CommandType.Text
			oData.oCommand.CommandText = sCmd
			oData.oCommand.ExecuteNonQuery()
			oData.commitTrans()
			oData.closeConnection()
			Return True
		Catch ex As Exception
			sErrDesc = "Source : " & ex.Source & " , Desc : " & ex.Message
			oData.rollbackTrans()
			oData.closeConnection()
			Return False
		End Try
	End Function

	Public Function DisplayAgrementAssetNo(ByVal pBranchid As String, ByVal pApplicationID As String, ByVal pAssetSeqNo As String) As DataSet
		'pActionId pSearchBy pSearch pOrderBy page
		Dim oDs As DataSet
		Dim oData As New ClsData
		Dim sCmd As String

		sCmd = "SELECT refof.office_code as branchid, " &
				"app.app_no as applicationid,  " &
				"rtrim(agrmnt.agrmnt_no) as AgreementNo,   " &
				"cust.cust_Name as name,   " &
				"AM.ASSET_NAME  as description,  " &
				"AT.asset_Type_name as description,    " &
				"AA.SERIAL_NO_1 as SerialNo1, AA.SERIAL_NO_2 as SerialNo2,   " &
				"AA.LICENSE_PLATE_NO licenseplate,    " &
				"ISNULL(AAC.ATTR_CONTENT,'-') AS COLOR,   " &
				"AA.MANUFACTURING_YEAR as ManufacturingYear,   " &
				"(Case when AA.mr_asset_usage = 'C' then 'Commercial' " &
				"		when AA.mr_asset_usage = 'N' then 'Non Commercial' " &
				"		when AA.mr_asset_usage = 'S' then 'Else' else 'S' end) as Usage,  " &
				"isnull(CONVERT(VARCHAR(11), REPH.repo_dt, 106), '')  repossesDate,    " &
				"isnull(ras.ref_asset_stat_code,'') AssetStatus,   " &
				"isnull(aprsl_h.APPRAISAL_AMT,0) EstimationAmount, " &
				"isnull(ral.ral_req_no,'') RALNO,   " &
				"isnull(reph.asset_location,'') AssetLocation,   " &
				"qrybpkb.doc_no BPKB, " &
				"qrystnk.doc_no STNK, " &
				"isnull(aprsl_h.APPRAISAL_AMT,0) as estimationamountnumber,  " &
				"AT.Asset_Type_ID as assettypeid,  " &
				"qrybpkb.doc_no as doknumberautomotif, '' as doknumberhe, '' as doknumbermachine, '' as doknumberkapal, '' as doknumberproperty,  " &
				"isnull(linksam.applicationid,0) samcfexist,  " &
				"isnull(CONVERT(VARCHAR(11), linksam.submitdate, 106), '') as submitdate,    " &
				"isnull(linksam.submituser,'') as submituser,   " &
				"isnull(linksam.statusproses,'') statusproses  " &
				"FROM bnf_confinsMin1.dbo.agrmnt   with(nolock)    " &
				"left join    " &
				"	bnf_confinsMin1.dbo.ref_office REFOF with (nolock) on agrmnt.ref_office_id = REFOF.ref_office_id   " &
				"left join    " &
				"	bnf_confinsMin1.dbo.APP APP with (nolock) on agrmnt.app_id = APP.app_id   " &
				"INNER JOIN     " &
				"	bnf_confinsMin1.dbo.cust  with(nolock) ON agrmnt.Cust_ID = Cust.Cust_ID    " &
				"left join    " &
				"	bnf_confinsMin1.dbo.AGRMNT_ASSET AA with (nolock) on agrmnt.agrmnt_id = AA.agrmnt_id and agrmnt.app_id = AA.app_id   " &
"LEFT JOIN " &
"(  " &
"SELECT AGRASDOC.AGRMNT_ASSET_DOC_ID, AGRASDOC.AGRMNT_ASSET_ID, AGRASDOC.ASSET_DOC_LIST_ID, AGRASDOC.DOC_NO, DOCLIST.REF_ASSET_DOC_ID, REFDOC.ASSET_DOC_CODE  " &
"FROM bnf_confinsMin1.dbo.AGRMNT_ASSET_DOC AGRASDOC  WITH(NOLOCK) " &
"left JOIN  " &
"	bnf_confinsMin1.dbo.ASSET_DOC_LIST DOCLIST WITH(NOLOCK) ON DOCLIST.ASSET_DOC_LIST_ID = AGRASDOC.ASSET_DOC_LIST_ID  " &
"	and DOCLIST.ASSET_TYPE_ID=1 " &
"inner JOIN  " &
"	bnf_confinsMin1.dbo.REF_ASSET_DOC REFDOC WITH(NOLOCK) ON DOCLIST.REF_ASSET_DOC_ID = REFDOC.REF_ASSET_DOC_ID   " &
"	and REFDOC.ASSET_DOC_CODE = 'BPKB'  " &
"	AND REFDOC.REF_ASSET_DOC_ID=11 " &
")QRYBPKB ON AA.AGRMNT_ASSET_ID = QRYBPKB.AGRMNT_ASSET_ID " &
"LEFT JOIN " &
"(  " &
"SELECT AGRASDOC.AGRMNT_ASSET_DOC_ID, AGRASDOC.AGRMNT_ASSET_ID, AGRASDOC.ASSET_DOC_LIST_ID, AGRASDOC.DOC_NO,  " &
"DOCLIST.REF_ASSET_DOC_ID, REFDOC.ASSET_DOC_CODE  " &
"FROM bnf_confinsMin1.dbo.AGRMNT_ASSET_DOC AGRASDOC  WITH(NOLOCK) " &
"left JOIN  " &
"	bnf_confinsMin1.dbo.ASSET_DOC_LIST DOCLIST WITH(NOLOCK) ON DOCLIST.ASSET_DOC_LIST_ID = AGRASDOC.ASSET_DOC_LIST_ID  " &
"	and DOCLIST.ASSET_TYPE_ID=1 " &
"inner JOIN  " &
"	bnf_confinsMin1.dbo.REF_ASSET_DOC REFDOC WITH(NOLOCK) ON DOCLIST.REF_ASSET_DOC_ID = REFDOC.REF_ASSET_DOC_ID   " &
"	and REFDOC.ASSET_DOC_CODE = 'STNK'  " &
"	AND REFDOC.REF_ASSET_DOC_ID=53 " &
")QRYSTNK ON AA.AGRMNT_ASSET_ID = QRYSTNK.AGRMNT_ASSET_ID " &
"Inner join    " &
				"	confinsproduction.bnf_confins.dbo.REF_ASSET_STAT RAS with (nolock) on aa.ref_asset_stat_id = RAS.ref_asset_stat_id   " &
				"left JOIN    " &
				"	bnf_confinsMin1.dbo.ASSET_MASTER AM WITH (NOLOCK) ON AA.ASSET_MASTER_ID = AM.ASSET_MASTER_ID   " &
				"left join    " &
				"	bnf_confinsMin1.dbo.ASSET_HIERARCHY_L1 AHL1 with(nolock) ON AM.ASSET_HIERARCHY_L1_ID = AHL1.ASSET_HIERARCHY_L1_ID   " &
				"INNER JOIN     " &
				"	bnf_confinsMin1.dbo.Asset_Type AT with(nolock) ON AHL1.Asset_Type_ID = AT.Asset_Type_ID    " &
				"LEFT JOIN    " &
				"	bnf_confinsMin1.dbo.ASSET_ATTR_CONTENT AAC WITH (NOLOCK) ON AA.AGRMNT_ASSET_ID = AAC.AGRMNT_ASSET_ID  and aac.asset_attr_id in (3) " &
				"LEFT JOIN    " &
				"	confinsproduction.bnf_confins.dbo.REPO_H REPH WITH (NOLOCK) ON AA.AGRMNT_ASSET_ID = REPH.AGRMNT_ASSET_ID   " &
				"LEFT JOIN    " &
				"	confinsproduction.bnf_confins.dbo.RAL RAL WITH (NOLOCK) ON REPH.ral_id = RAL.ral_id   " &
				"LEFT JOIN    " &
				"    confinsproduction.bnf_confins.dbo.INV_ASSET_APPRAISAL_H  aprsl_h with (nolock) on reph.repo_h_id = aprsl_h.repo_h_id " &
				"left join    " &
				"	(    " &
				"	select distinct tab_mar_Asset.applicationid, tab_mar_Asset.assetseqno ,   " &
				"	isnull(tab_mar_ProsesPenjualan_Internal.statusproses,'0') as statusproses,    " &
				"	tab_mar_msstatusproses.statusprosesdesc, tab_mar_ProsesPenjualanextlelang_Internal.tglmulailelang,    " &
				"	tab_mar_ProsesPenjualanextlelang_Internal.tglakhirlelang, tab_mar_asset.assetdescription_correctionsam ,    " &
				"	tab_MAR_msAlamatPool.alamatpool, tab_mar_asset.usrins as submitdate, tab_mar_asset.dtmins submituser" &
				"	from samCF.dbo.mar_Asset tab_mar_asset with(nolock)    " &
				"	left join    " &
				"		samCF.dbo.mar_ProsesPenjualan_Internal tab_mar_ProsesPenjualan_Internal  with(nolock)    " &
				"		on tab_mar_asset.applicationid = tab_mar_ProsesPenjualan_Internal.applicationid    " &
				"		and tab_mar_asset.assetseqno = tab_mar_ProsesPenjualan_Internal.assetseqno   " &
				"	left join    " &
				"		samCF.dbo.mar_msstatusproses tab_mar_msstatusproses  with(nolock)    " &
				"		on tab_mar_ProsesPenjualan_Internal.statusproses = tab_mar_msstatusproses.statusproses      " &
				"	left join samCF.dbo.mar_ProsesPenjualanextlelang_Internal tab_mar_ProsesPenjualanextlelang_Internal  with(nolock)    " &
				"		on tab_mar_Asset.applicationid = tab_mar_ProsesPenjualanextlelang_Internal.applicationid    " &
				"		and tab_mar_Asset.assetseqno = tab_mar_ProsesPenjualanextlelang_Internal.assetseqno      " &
				"	left join    " &
				"		samCF.dbo.MAR_AlamatPool_Internal tab_MAR_AlamatPool_Internal  with(nolock)    " &
				"		on tab_mar_Asset.applicationid = tab_MAR_AlamatPool_Internal.applicationid    " &
				"		and tab_mar_Asset.assetseqno = tab_MAR_AlamatPool_Internal.assetseqno      " &
				"	left join    " &
				"		samCF.dbo.MAR_msAlamatPool tab_MAR_msAlamatPool  with(nolock)    " &
				"		on tab_MAR_AlamatPool_Internal.poolid = tab_MAR_msAlamatPool.poolid   " &
				" where tab_mar_asset.applicationid='" & pApplicationID & "' " &
				"	) linksam on app.app_no = linksam.applicationid and AA.asset_seq_no = linksam.assetseqno        " &
				"where  app.app_no='" & pApplicationID & "' and AA.asset_seq_no='" & pAssetSeqNo & "'"

		oDs = oData.ExecuteQueryType3(sCmd, ClsData.ReturnType.DataSet)

		Return oDs
	End Function

End Class
