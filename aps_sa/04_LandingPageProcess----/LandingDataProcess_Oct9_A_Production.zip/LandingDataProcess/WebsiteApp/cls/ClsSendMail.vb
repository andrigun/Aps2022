Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Mail
Imports Microsoft.VisualBasic
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.HtmlControls
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.WebControls.ListControl
Imports System.Web.UI.WebControls.ListBox


Public Class ClsSendMail
    Public SmtpServer As String = ConfigurationSettings.AppSettings("SmtpServer")
    Public sqlconapps As New SqlConnection(ConfigurationManager.ConnectionStrings("Con").ConnectionString)
    Public sender_sam As String = ConfigurationSettings.AppSettings("sender_sam")
    Public sam_to As String = ConfigurationSettings.AppSettings("sam_to")
    Public sam_cc As String = ConfigurationSettings.AppSettings("sam_cc")
    Public sam_bcc As String = ConfigurationSettings.AppSettings("sam_bcc")
    Dim oLoad As New ClsApp

    Public Function SendMail(ByVal szSendTo As String, ByVal szSendFrom As String, ByVal szFromName As String, _
   ByVal notiftype As String, ByVal applicationid As String, ByVal assetseqno As String) As Boolean

        Dim oLoad As New ClsApp
        Dim oDs As New DataSet
        Dim sQuery As String
        'Dim jmlfoto As Integer
        'Dim emailcabang As String
        Dim isibody As String
        sQuery = "select top 1 nama from testing"

        Dim oAdapter As New SqlDataAdapter(sQuery, sqlconapps)
        Dim oDsmar As New DataSet
        oAdapter.Fill(oDsmar, "DataSet")
        notiftype = oDsmar.Tables(0).Rows(0).Item(0)
        isibody = "<center><u><b><font style='font-family: Tahoma;font-size:large;'>" & notiftype & "</font></b></u></center><br>"
        isibody = isibody & "<table id='tbGrid1' cellSpacing='1' cellPadding='2'  border='0' width='853px' align='center'>"
        isibody = isibody & "<tr><td align='left' style='font-family: Tahoma;font-size:smaller;BORDER-RIGHT: 0px; BORDER-TOP: 0px; BORDER-LEFT: 0px; BORDER-BOTTOM: 0px; BACKGROUND-COLOR: #e7e3e7;' colspan=3><b>INFORMASI ASSET</b></td></tr>"
        isibody = isibody & "<tr>"
        isibody = isibody & "<td style='width:22%;BACKGROUND-COLOR:#f4faff;font-family: Tahoma;font-size:smaller;'>Nama / Jenis Asset</td><td>:</td>"
        isibody = isibody & "<td style='width:78%;BACKGROUND-COLOR:#ffffff;font-family: Tahoma;font-size:smaller;'>PESAN ABC</td>"
        isibody = isibody & "</tr>"
        isibody = isibody & "</table>"

        'Holds message information.
        Dim mailMessage As System.Net.Mail.MailMessage = New System.Net.Mail.MailMessage()

        'Tidak perlu diubah-ubah (sama untuk live maupun testing)
        Dim SendFrom As String = sender_sam

        '!!!!!!! ATTENTION !!!!!!!!!!!
        '##### UNTUK APLIKASI REAL #########
        Dim SendTo As String = sam_to
        Dim SendCC As String = sam_cc
        Dim SendBCC As String = sam_bcc
        '##### UNTUK APLIKASI REAL #########

        mailMessage.From = New System.Net.Mail.MailAddress(SendFrom)
        mailMessage.To.Add(SendTo)
        mailMessage.CC.Add(SendCC)
        mailMessage.Bcc.Add(SendBCC)

        mailMessage.Subject = "Notifikasi contact us"

        'Create two views, one text, one HTML.
        Dim plainTextView As System.Net.Mail.AlternateView = System.Net.Mail.AlternateView.CreateAlternateViewFromString("body", Nothing, "text/plain")
        Dim htmlView As System.Net.Mail.AlternateView

        htmlView = System.Net.Mail.AlternateView.CreateAlternateViewFromString("<html><body>" & isibody & "</body></html>", Nothing, "text/html")

        'Add two views to message.
        mailMessage.AlternateViews.Add(plainTextView)
        mailMessage.AlternateViews.Add(htmlView)

        'Send message
        Dim smtpClient As New System.Net.Mail.SmtpClient()
        smtpClient.Send(mailMessage)
    End Function
End Class
