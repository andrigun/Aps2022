﻿Public Class GlobalVariables
    'username, branchid, branchfullname, pass
    Public Shared GlobaUserName As String
    Public Shared GlobalBranchId As String
    Public Shared GlobalBranchFullName As String
    Public Shared GlobalUserPass As String
    Public Shared GlobaUserName_var As String
    Public Shared GlobalUserPass_var As String
    Public Shared UserAksesGlobal As String
    Public Shared UserAge As Integer = 39
End Class
