﻿Imports System.Data
Imports System.Data.SqlClient

Public Class clsQry
    Dim sqlconapps As New SqlConnection(ConfigurationManager.ConnectionStrings("Conapps").ConnectionString)

    Public Function getListCamSurvey(ByVal currPage As Integer, ByVal rowPerPage As Integer,
      ByRef totalPage As Integer, ByVal reffnumber As String) As DataSet


        Dim oDs6 As Object
        Dim oData As New ClsData
        Dim sCmd As String
        Dim iErrNo

        sCmd = "exec usp_qry_CAMsurvey_BNFMOSS '" & reffnumber & "'"
        'sCmd = "select top 10 * from BNF_CONFINSMin1..COLL_AGRMNT"

        'oDs6 = oData.ExecuteQuery(sCmd, clsData.ReturnType.Paging, currPage, rowPerPage, totalPage)
        oDs6 = oData.executeQuery(sCmd, ClsData.ReturnType.DataSet)


        Return oDs6

    End Function
End Class
