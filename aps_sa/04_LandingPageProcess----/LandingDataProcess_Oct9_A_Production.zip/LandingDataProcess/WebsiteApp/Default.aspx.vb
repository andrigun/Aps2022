﻿Partial Public Class _Default
    Inherits System.Web.UI.Page
    Dim oComm As New clsCommon
    Dim workingserver As String = ConfigurationSettings.AppSettings("workingserver")

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If workingserver = "41" Then
            hidUr.Value = Request.ServerVariables("HTTP_REFERER")
        Else
            If (SecurityCek(Request.ServerVariables("HTTP_REFERER")) = False) Then
                Response.Redirect("WarningPage.aspx")
            End If
        End If
        hidUr.Value = Request.ServerVariables("HTTP_REFERER")
    End Sub
    Function SecurityCek(ByVal path As String) As Boolean
        Dim Uri As String
        Uri = oComm.get_OPENPAGE_ALLOWED
        If Trim(LCase(Uri)) = Trim(LCase(path)) Then
            Return True
        Else
            Return False
        End If
    End Function
End Class