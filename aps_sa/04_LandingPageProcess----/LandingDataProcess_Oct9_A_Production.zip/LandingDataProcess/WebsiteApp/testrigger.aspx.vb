﻿Public Class testrigger
	Inherits System.Web.UI.Page

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

	End Sub



	Protected Sub RunButton_Click(ByVal sender As Object, ByVal e As EventArgs)
		Response.Write("Button method called")
	End Sub


End Class