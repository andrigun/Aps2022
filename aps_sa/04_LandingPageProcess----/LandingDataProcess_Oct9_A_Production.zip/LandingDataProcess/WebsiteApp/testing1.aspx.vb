﻿Public Partial Class testing1
    Inherits System.Web.UI.Page

    Dim test As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        Dim sUserID As String
        Dim sUserEncrypted As String
        Dim sUserName As String
        Dim test As String
        Dim oUser As New clsUser

        sUserID = "hans.sumanta"
        sUserEncrypted = "AaBCtDEnFGaHImJKuLMsNOsPQnRSaTUhV"

        sUserName = oUser.getUserNameIfValid(sUserID, sUserEncrypted)

        Session("UserName") = sUserName
        Session("userLogin") = sUserID

        test = Session("UserName")

        '  Response.Redirect("./testing2.aspx")



    End Sub

End Class