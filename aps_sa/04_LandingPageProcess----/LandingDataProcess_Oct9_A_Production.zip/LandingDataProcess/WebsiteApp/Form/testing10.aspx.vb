﻿Imports System.IO
Imports System.Text
Imports System.Security.Cryptography

Public Class testing10
	Inherits System.Web.UI.Page
	Dim var1 As String
	Dim var2 As String

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
		If Not Me.IsPostBack Then
			var1 = Decrypt(HttpUtility.UrlDecode(Request.QueryString("name")))
			var2 = Decrypt(HttpUtility.UrlDecode(Request.QueryString("technology")))
		End If
	End Sub

	Private Function Decrypt(cipherText As String) As String
		Dim EncryptionKey As String = "MAKV2SPBNI99212"
		cipherText = cipherText.Replace(" ", "+")
		Dim cipherBytes As Byte() = Convert.FromBase64String(cipherText)
		Using encryptor As Aes = Aes.Create()
			Dim pdb As New Rfc2898DeriveBytes(EncryptionKey, New Byte() {&H49, &H76, &H61, &H6E, &H20, &H4D,
			 &H65, &H64, &H76, &H65, &H64, &H65,
			 &H76})
			encryptor.Key = pdb.GetBytes(32)
			encryptor.IV = pdb.GetBytes(16)
			Using ms As New MemoryStream()
				Using cs As New CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write)
					cs.Write(cipherBytes, 0, cipherBytes.Length)
					cs.Close()
				End Using
				cipherText = Encoding.Unicode.GetString(ms.ToArray())
			End Using
		End Using
		Return cipherText
	End Function

End Class