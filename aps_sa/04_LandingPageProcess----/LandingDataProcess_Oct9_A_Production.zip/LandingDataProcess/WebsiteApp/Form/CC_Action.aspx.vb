﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Text
Imports System.Security.Cryptography
Imports System.Web.Mail
Public Class CC_Action
	Inherits System.Web.UI.Page
	Dim reffnumber As String
	Dim MailFunc As New ClsSendMail_SubmitCabang

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


		If Not IsPostBack Then
			If Session("userid") = "" Then
				Exit Sub
			End If
			userid.Text = Session("userid")
			branchid.Text = Session("branchid")
		End If


		txtUserId.Value = Session("userid")
		txtCabang.Value = Session("BranchId")

		Dim x As Integer
		Dim sTable As String
		Dim oDs As DataSet
		Dim oLoad As New ClsApp
        Dim OComm As New clsCommon



        If Not Me.IsPostBack Then
            reffnumber = Decrypt(HttpUtility.UrlDecode(Request.QueryString("reID")))
            txtDataId.Value = reffnumber
            oDs = oLoad.displaydatapagedetailreview(reffnumber)
            sTable = ""
            With oDs.Tables(0)
                If (.Rows(x).Item("statusid") = "RQSVY") Then
					lblactivity.Text = "Set Status"
				Else
					lblactivity.Text = "View Data"
					btnRDSVY.Visible = False
                    btnRQSCL.Visible = False
                End If

                txtprospectid.Text = .Rows(x).Item("reffnumber")
                txtname.Text = .Rows(x).Item("name")
                txttgllahir.Text = .Rows(x).Item("birthDate")
                txtphone.Text = .Rows(x).Item("mobile")
                txtstatus.Text = .Rows(x).Item("statusname")

            End With



        End If


		Exit Sub
	End Sub


	Private Function Decrypt(cipherText As String) As String
		Dim EncryptionKey As String = "MAKV2SPBNI99212"
		cipherText = cipherText.Replace(" ", "+")
		Dim cipherBytes As Byte() = Convert.FromBase64String(cipherText)
		Using encryptor As Aes = Aes.Create()
			Dim pdb As New Rfc2898DeriveBytes(EncryptionKey, New Byte() {&H49, &H76, &H61, &H6E, &H20, &H4D,
			 &H65, &H64, &H76, &H65, &H64, &H65,
			 &H76})
			encryptor.Key = pdb.GetBytes(32)
			encryptor.IV = pdb.GetBytes(16)
			Using ms As New MemoryStream()
				Using cs As New CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write)
					cs.Write(cipherBytes, 0, cipherBytes.Length)
					cs.Close()
				End Using
				cipherText = Encoding.Unicode.GetString(ms.ToArray())
			End Using
		End Using
		Return cipherText
	End Function


	'Protected Sub Button2_Click(ByVal sender As Object, ByVal e As EventArgs)
	'	Response.Write("Button method called ........ dari code behind")
	'	'	MailFunc.SendMail("a", "b", "c", 1, "Value1", "Value2")
	'End Sub



	'Protected Sub btnsendemail_Click(sender As Object, e As EventArgs) Handles btnsendemail.Click
	'	MailFunc.SendMail("a", "b", "c", 1, "Value1", "Value2")
	'End Sub


	'Protected Sub RunButton_Click(ByVal sender As Object, ByVal e As EventArgs)
	'	MsgBox("abc")

	'	'	Response.Write("Button method called")
	'	MailFunc.SendMail("a", "b", "c", 1, "Value1", "Value2")

	'End Sub


End Class


