﻿Imports System.IO
Imports System.Data
Imports System.Data.SqlClient

Partial Public Class review_2
    Inherits System.Web.UI.Page
    Dim viewreID As String
    Dim userlogin As String
    Dim sesbranchid As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        '   Response.Redirect(Request.RawUrl)
        Session("testing") = Request.QueryString("reID")
        '  Response.Redirect("review_3.aspx")


        txtUserId.Value = Session("userLogin")
        txtCabang.Value = Session("BranchId")
        txtDataId.Value = Request.QueryString("reID")

        Dim var1 As String
        var1 = Session("Name")

        var1 = var1

        Session("testing") = Request.QueryString("reID")
        '  Response.Redirect("review_3.aspx")

        Dim x As Integer
        Dim sTable As String
        Dim oDs As DataSet
        Dim oLoad As New ClsApp
        Dim OComm As New clsCommon

        viewreID = Request.QueryString("reID")
        oDs = oLoad.displaydatapagedetailreview(viewreID)

        sTable = ""
        With oDs.Tables(0)
            txtprospectid.Text = .Rows(x).Item("idofthistable")
            txtname.Text = .Rows(x).Item("name")
            txtktp.Text = .Rows(x).Item("nationalId")
            txttgllahir.Text = .Rows(x).Item("birthDate")
            txtphone.Text = .Rows(x).Item("mobile")
        End With
        Exit Sub
    End Sub
End Class


'Private Sub MessageBox(ByVal strMsg As String)
'    Dim lbl As New Label
'    lbl.Text = "<script language='javascript'>" & Environment.NewLine _
'               & "window.alert(" & "'" & strMsg & "'" & ")</script>"
'    Page.Controls.Add(lbl)
'End Sub
'Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
'    assetidlist = ""
'    Dim cb2 As CheckBox = GridView1.HeaderRow.FindControl("CheckBox2")
'    Dim cbterpilih As Boolean = False
'    Dim cb As CheckBox = Nothing
'    Dim n As Integer = 0

'    Do Until n = GridView1.Rows.Count
'        cb = GridView1.Rows.Item(n).FindControl("CheckBox1")
'        If cb IsNot Nothing AndAlso cb.Checked Then
'            cbterpilih = True
'            assetidlist = assetidlist & Trim((GridView1.Rows(n).Cells(1).Text)) & ", "
'        End If
'        If cb.Checked = False Then
'            If cb2 IsNot Nothing Then
'                cb2.Checked = False
'            End If
'        End If
'        n += 1
'    Loop
'End Sub

'Protected Sub Button4_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button4.Click
'    Dim sql2 As String = "update tblinvoiceut set lockstatus = 'T' where invoiceid ='" & viewreID & "'"
'    Dim oDsw As DataSet = getData(sql2)
'    Button1.Visible = False
'    GridView1.Enabled = False
'    GridView1.EditIndex = False
'    Button4.Visible = False
'End Sub

'    Protected Sub OnConfirm(ByVal sender As Object, ByVal e As EventArgs) Handles Button2.Click
'        Dim lbl As New Label
'        On Error GoTo errHandle
'        Dim bIsSuspend As Boolean
'        Dim sErrDesc As String = ""
'        Dim status_invoice As String
'        Dim confirmValue As String = Request.Form("confirm_value")
'        If confirmValue = "Yes" Then
'            updateinvoicestatus()
'        End If
'errHandle:
'    End Sub

'    Sub updateinvoicestatus()
'        Dim lbl As New Label
'        On Error GoTo errHandle
'        Dim bIsSuspend As Boolean
'        Dim sErrDesc As String = ""
'        Dim status_invoice As String

'        txtRequestId.Text = txtRequestId.Text
'        Dim xx As String = txtReID.Text

'        ''Query untuk mendapatkan invoice id :
'        ' Dim qgetinvoiceid As String = "select invoiceid from tblinvoiceUT where invoiceno = '" & txtinvoicenodisplay.Text & "'"
'        ' Dim oDsw As DataSet = getData(qgetinvoiceid)
'        ' invoiceid = oDsw.Tables(0).Rows(0).Item("invoiceid")
'        hdninvoiceid.Value = invoiceid
'        lbl.Text = "<script language='javascript'>insDat_Pre();</script>"
'        Page.Controls.Add(lbl)
'        ' oApp.updateInvoiceStatus_UT(invoiceid, "C", txtinvoicenodisplay.Text, userlogin)
'        lbl.Text = "<script language='javascript'>var str; str='<b>Invoice Status Updated.</b>'; showMsgBox('Information', str, 'OK', '', 'CloseDialogBox()', '', 300, '','','');</script>"
'        Page.Controls.Add(lbl)
'        Button2.Visible = False
'        'tambahfilemou.Visible = False
'        '  invstatus1.Text = "Lunas"
'        '  invstatus2.Text = "Lunas"
'        Exit Sub
'errHandle:
'    End Sub



