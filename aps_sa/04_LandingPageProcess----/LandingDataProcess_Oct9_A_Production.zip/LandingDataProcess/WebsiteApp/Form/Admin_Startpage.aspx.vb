﻿Imports System.IO
Imports System.Text
Imports System.Security.Cryptography
Public Class Admin_Startpage
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

		'refresh every 30 seconds
		'Response.AppendHeader("Refresh", "30")

		'settimeout
		Session.Timeout = 20

		If Not IsPostBack Then
			If Session("userid") = "" Then
				Exit Sub
			End If
		End If
		txtUserID.Value = Session("userid")
		txtBranchId.Value = Session("branchid")
		txtAccess.Value = Session("akses")
		userid.Text = Session("userid")
		branchid.Text = Session("branchid")
	End Sub


	Private Function Encrypt(clearText As String) As String
		Dim EncryptionKey As String = "MAKV2SPBNI99212"
		Dim clearBytes As Byte() = Encoding.Unicode.GetBytes(clearText)
		Using encryptor As Aes = Aes.Create()
			Dim pdb As New Rfc2898DeriveBytes(EncryptionKey, New Byte() {&H49, &H76, &H61, &H6E, &H20, &H4D,
				 &H65, &H64, &H76, &H65, &H64, &H65,
				 &H76})
			encryptor.Key = pdb.GetBytes(32)
			encryptor.IV = pdb.GetBytes(16)
			Using ms As New MemoryStream()
				Using cs As New CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write)
					cs.Write(clearBytes, 0, clearBytes.Length)
					cs.Close()
				End Using
				clearText = Convert.ToBase64String(ms.ToArray())
			End Using
		End Using
		Return clearText
	End Function

	Protected Sub btnredirect_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnredirect.Click
		Response.Redirect(String.Format("Admin_Action.aspx?isviewinvho=0&reID={0}&view=info", HttpUtility.UrlEncode(Encrypt(txtdataid.Value))))
		Exit Sub
	End Sub

	Private Sub MessageBox(ByVal strMsg As String)
		Dim lbl As New Label
		lbl.Text = "<script language='javascript'>" & Environment.NewLine _
							 & "window.alert(" & "'" & strMsg & "'" & ")</script>"
		Page.Controls.Add(lbl)
		Exit Sub
	End Sub

End Class