﻿Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.HtmlControls
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.WebControls.ListControl
Imports System.Web.UI.WebControls.ListBox
Imports System
Imports System.Collections.Generic
Imports System.Linq



Partial Public Class startpage_
    Inherits System.Web.UI.Page
    ' Inherits System.Web.Services.WebService
    Dim oData As New ClsData
    Dim oDs As New DataSet
    Dim oUser As New clsUser
    Public varvar As String
    Public datastring As String
    Public x As String


    <WebMethod(EnableSession:=True)> _
    Public Shared Function GetCurrentTime(ByVal name As String) As String
        'Return "Hello " & name & Environment.NewLine & "The Current Time is: " & _
        '    DateTime.Now.ToString()
        ' Session("testing") = "abc"
        'Dim xStr As String
        'Dim Script, strFinal, namabulan, namatahun, gabBulTah, gabBulTahNext As String

        'Script = "$(document).ready(function() {" & xStr & "})"
        'name = Script & "__" & name

        HttpContext.Current.Session("Name") = name

        Return name

    End Function





    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim pUserName, pBranchID, pBranchName, pAcccessType, pUserId As String
		'   Dim a As String

		'    a = txtUserName.Text

		If Not IsPostBack Then

			'        datastring = "ID06"


			pUserName = Session("userLogin")
            pUserName = Convert.ToString(Session("userLogin"))

            'lblString.Text = "Welcome " & Convert.ToString(Session("FirstName")) & Convert.ToString(Session("LastName"))

            'pUserName = "hans.sumanta"

            oDs = oUser.getUserInformation(pUserName)
            pBranchID = oDs.Tables(0).Rows(0).Item(1)
            pBranchName = oDs.Tables(0).Rows(0).Item(2)
            pAcccessType = oDs.Tables(0).Rows(0).Item(4)
            pUserId = oDs.Tables(0).Rows(0).Item(5)
            Session("BranchID") = pBranchID
            Session("AccessType") = pAcccessType
            Session("UserId") = pUserId

            'txtDataId.Value = dataid.Text

            'popup screen
            'txtUserID.Value = Session("userLogin")
            'txtCabang.Value = Session("BranchId")
            'txtDataId.Value = Request.QueryString("reID")


            'txtUserID.Value = "abc"
            'txtCabang.Value = Session("BranchId")
            'txtDataId.Value = "abc"

        End If

        Exit Sub
    End Sub


    Protected Sub Getvalue(ByVal name As String)

        Session("testing") = name


    End Sub

	'Protected Sub txtFiltrarNomeUtente_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtFiltrarNomeUtente.TextChanged
	'    Dim a As String
	'    a = "anc"
	'    TextBox1.Text = "jakarta"
	'    a = a
	'End Sub




	'Private Sub MessageBox(ByVal strMsg As String)
	'    Dim lbl As New Label
	'    lbl.Text = "<script language='javascript'>" & Environment.NewLine _
	'               & "window.alert(" & "'" & strMsg & "'" & ")</script>"
	'    Page.Controls.Add(lbl)
	'    Exit Sub
	'End Sub



End Class


