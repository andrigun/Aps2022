﻿Public Partial Class review_3
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim var1 As String
        var1 = Session("testing")

        var1 = var1
        TextBox1.Text = var1

    End Sub

End Class