﻿Public Partial Class testing2
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        Dim oData As New ClsData
        Dim oDs As New DataSet
        Dim oUser As New clsUser


        Dim pUserName As String



        pUserName = Session("UserName")

        ' pUserName = Session("variable").ToString()

        pUserName = pUserName

        pUserName = pUserName


    End Sub

End Class